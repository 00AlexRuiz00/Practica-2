package com.example.planetas;

import android.os.Bundle;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ListView;
        import android.widget.TextView;
        import androidx.appcompat.app.AppCompatActivity;
        import java.util.ArrayList;
        import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Planet> planets;
    private PlanetAdapter adapter;
    private TextView planetInfoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        planetInfoTextView = findViewById(R.id.planetInfoTextView);

        planets = new ArrayList<>();
        planets.add(new Planet("Mercury", "The smallest and fastest planet in our solar system."));
        planets.add(new Planet("Venus", "The second planet from the Sun, known for its thick atmosphere."));
        planets.add(new Planet("Earth", "Our home planet, the third planet from the Sun."));
        planets.add(new Planet("Mars", "The fourth planet from the Sun, often called the Red Planet."));

        adapter = new PlanetAdapter(this, planets);
        ListView planetsListView = findViewById(R.id.planetsListView);
        planetsListView.setAdapter(adapter);

        planetsListView.setOnItemClickListener((parent, view, position, id) -> {
            Planet selectedPlanet = planets.get(position);
            planetInfoTextView.setText(selectedPlanet.getDescription());
        });
    }
}
